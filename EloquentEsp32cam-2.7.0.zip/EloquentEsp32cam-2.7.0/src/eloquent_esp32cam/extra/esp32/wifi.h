#ifndef ELOQUENT_EXTRA_WIFI
#define ELOQUENT_EXTRA_WIFI

#include "./wifi/sta.h"

#endif